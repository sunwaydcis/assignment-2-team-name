import Data.List (maximumBy, groupBy, sortOn)
import Data.Function (on)
import Data.Char (isDigit)
import Text.CSV

-- Define a data structure for the hospital record
data HospitalRecord = HospitalRecord
  { date           :: String
  , state          :: String
  , beds           :: Int
  , bedsCovid      :: Int
  , bedsNoncrit    :: Int
  , admittedPUI    :: Int
  , admittedCovid  :: Int
  , admittedTotal  :: Int
  } deriving (Show)

-- Function to parse a single record from a CSV row
parseRecord :: [String] -> HospitalRecord
parseRecord [d, st, b, bc, bn, ap, ac, at, _, _, _, _, _, _] =
  HospitalRecord d st (read b) (read bc) (read bn) (read ap) (read ac) (read at)
parseRecord _ = error "Invalid record format"

-- Function to load the CSV and parse all rows
loadRecords :: FilePath -> IO [HospitalRecord]
loadRecords path = do
  content <- readFile path
  case parseCSV path content of
    Right csv -> return $ map parseRecord (tail csv) -- Skip header
    Left err  -> error $ "Error parsing CSV: " ++ show err

-- Question 1: Find the state with the highest total hospital beds
highestTotalBedsState :: [HospitalRecord] -> String
highestTotalBedsState records =
  let grouped = groupBy ((==) `on` state) $ sortOn state records
      stateBeds = map (\g -> (state (head g), sum (map beds g))) grouped
  in fst $ maximumBy (compare `on` snd) stateBeds

-- Question 2: Calculate the ratio of beds for COVID-19 to total beds
covidBedsRatio :: [HospitalRecord] -> Double
covidBedsRatio records =
  let totalBeds = sum (map beds records)
      totalCovidBeds = sum (map bedsCovid records)
  in fromIntegral totalCovidBeds / fromIntegral totalBeds

-- Question 3: Compute average admissions by category for each state
averageAdmissions :: [HospitalRecord] -> [(String, (Double, Double, Double))]
averageAdmissions records =
  let grouped = groupBy ((==) `on` state) $ sortOn state records
      averages g =
        let s = state (head g)
            totalRecords = fromIntegral (length g)
            avgPUI = sum (map admittedPUI g) / totalRecords
            avgCovid = sum (map admittedCovid g) / totalRecords
            avgTotal = sum (map admittedTotal g) / totalRecords
        in (s, (avgPUI, avgCovid, avgTotal))
  in map averages grouped

-- Main function to load data and answer the questions
main :: IO ()
main = do
  records <- loadRecords "hospital.csv"
  
  -- Question 1
  putStrLn $ "State with highest total hospital beds: " ++ highestTotalBedsState(records)
  
  -- Question 2
  putStrLn $ "Ratio of COVID-19 beds to total beds: " ++ show (covidBedsRatio records)
  
  -- Question 3
  putStrLn "Average admissions per state (PUI, COVID, Total):"
  mapM_ print (averageAdmissions records)
